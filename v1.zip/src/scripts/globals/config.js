const CONFIG = {
    KEY: "12345",
    // BASE_URL: 'https://api.themoviedb.org/3/',
    // BASE_IMAGE_URL: 'https://image.tmdb.org/t/p/w500/',
    // DEFAULT_LANGUAGE: 'en-us',
    CACHE_NAME: new Date().toISOString()
    // restaurant 
    BASE_URL: 'https://restaurant-api.dicoding.dev',
    // BASE_URL_IMAGE_SM: "https://restaurant-api.dicoding.dev/images/medium/",
    BASE_URL_IMAGE_MD: "https://restaurant-api.dicoding.dev/images/medium/",
    BASE_URL_IMAGE_SM: "https://restaurant-api.dicoding.dev/images/small/",
    
}

export default CONFIG;