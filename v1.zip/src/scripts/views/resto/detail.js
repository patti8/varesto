import RestaurantDbSource from '../../data/restaurantdb-source';
import UrlParser from '../../routes/url-parser';
import { createRestoDetailTemplate } from '../templates/template-creator';

const Detail = {
    async render() {
        return `
            <h1>Detail Resto</h1>
            <br>
            <div id="makan" class="makan"></div>
        `;
    },

    async afterRender() {
        const url = UrlParser.parseActiveUrlWithoutCombiner();
        const makan = await RestaurantDbSource.getDetail(url.id);
        // console.log(makan)
        const makanContainer = document.querySelector('#makan');
        makanContainer.innerHTML = createRestoDetailTemplate(makan)
    }
};

export default Detail