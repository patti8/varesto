import UrlParser from '../../routes/url-parser';
import TheMovieDbSource from '../../data/restaurantdb-source';
import { createMovieDetailTemplate, createLikeButtonTemplate } from '../templates/template-creator';
 
const Detail = {
  async render() {
    return `
      <div id="movie" class="movie"></div>
      <div id="likeButtonContainer"></div>
    `;
  },
 
  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    const movie = await RestaurantDb.tampilSemua(url.id);
    const movieContainer = document.querySelector('#movie');
    movieContainer.innerHTML = createMovieDetailTemplate(movie);
    console.log(movie);
    LikeButtonInitiator.init({
      likeButtonContainer: document.querySelector('#likeButtonContainer'),
      movie,
    });
  },
};
 
export default Detail;